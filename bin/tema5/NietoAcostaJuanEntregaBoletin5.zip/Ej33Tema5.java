/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tema5;

import java.util.Scanner;

/**
 *
 * @author Juan
 */
public class Ej33Tema5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Este programa muestra la letra U por pantalla con una altura introducida por teclado");
        System.out.println("------------------------------------------------------------------------------------");
        System.out.print("Introduce la altura: ");
        int h = s.nextInt();
        
    }
    
}
